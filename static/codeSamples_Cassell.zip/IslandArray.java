// Java program	IslandArray
// Course	      CSE1302 MW NIGHT
// Name           Laura Cassell
// Assignment#    Project 2
// Due Date       10/03/2010
// A two-dimensional array (diagram available in class) represents an island surrounded by water (outside edges of the array).   
//Two bridges lead off of the island – the location of each will be part of the input or generated with a random number.  
//Make sure the bridges are not in the corners because they will be unreachable.  A mouse is placed on one of the remaining land squares of the array – 
//the location of which will also be determined by the input or random number.  Write a program to make the mouse take a walk across the island.  
//The mouse is allowed to travel one square at a time, either horizontally or vertically.  A random number from 1 through 4 should be used to decide 
//which direction the mouse is to take.  The mouse drowns when he hits the water; he escapes when he enters a bridge.  
//You may generate a random number for the walk up to 20 times.  If the mouse does not find his way off the island by the 20th try, 
//he will die of starvation. 


import java.util.*; //implementing all classes in the java.util package

public class IslandArray
{
    public static void main (String[] args)
    {

	Scanner scan = new Scanner(System.in);
	int min = 0;
	int max = 0; 
	int escapes = 0;
	int starves = 0;
	int drowns = 0;
	String mouseStr;
	String[] mouse;
	String coordinates;
	String[] m1coord;
	String[] m2coord;	
	
  // Initializing the size of the map and pre-filling all slots
  for ( int tries = 0; tries <=5; tries++)
  {
   System.out.print ("Enter the size of the Map (10 or less)"); 
   max = scan.nextInt();
	
	int [] [] mapArray = new int [max] [max]; 
	int [] [] countArray = new int [max] [max];
	
	for (int i = 0; i < max  ; i++)
            {
				for (int j = 0; j < max; j++)
              		{
							if(i == min || i == max-1 || j == min || j == max-1)
								{
								mapArray[i][j] = -1;
								}
							else {
								mapArray[i][j] = 0;
								}		
                  }
				}
	//Assigning certain slots specific values for mouse and 2 bridges
	System.out.print ("Enter the starting point for the mouse with two numbers, 1-8 delimited by a comma (i.e: 2,5)"); 
   mouseStr = scan.next();
	mouse = mouseStr.split(",");
	int mouse0 = Integer.parseInt(mouse[0]);
	int mouse1 = Integer.parseInt(mouse[1]);

	mapArray[mouse0][mouse1] = 1;
	
	System.out.print ("Enter the starting point for the 1st bridge with two numbers, 1-8 delimited by a comma (i.e: 2,5)"); 
   coordinates = scan.next();
	m1coord = coordinates.split(",");
	mapArray[Integer.parseInt(m1coord[0])][Integer.parseInt(m1coord[1])] = 99;
	int m1coord0 = Integer.parseInt(m1coord[0]);
	int m1coord1 = Integer.parseInt(m1coord[1]);

	
	System.out.print ("Enter the starting point for the 2nd bridge with two numbers, 1-8 delimited by a comma (i.e: 2,5)"); 
  	coordinates = scan.next();
	m2coord = coordinates.split(",");
	mapArray[Integer.parseInt(m2coord[0])][Integer.parseInt(m2coord[1])] = 99;
	int m2coord0 = Integer.parseInt(m2coord[0]);
	int m2coord1 = Integer.parseInt(m2coord[1]);

	
		for (int i = 0; i < max  ; i++)
            {
				for (int j = 0; j < max; j++)
				{
             	System.out.print(mapArray[i][j] + "\t");
				}
		System.out.println();
		}
		 

	
	for (int x=0; x<=20; x++){
		Random randGen = new Random();
		int move;
		
		move = randGen.nextInt(4)+1;
		
		switch(move) {
			case 1:	if (mapArray[mouse0-1][mouse1] == -1)
						{
						System.out.println("Your mouse has drowned, please try again.");
						drowns++;
						x=21;
						}
						else if (mapArray[mouse0-1][mouse1] == 99)
						{
						System.out.println("Your mouse has Escaped! hooray!");
						escapes++;
						x=21;
						}
						else
						{
						mapArray[mouse0-1][mouse1] = mapArray[mouse0][mouse1];
						mouse0 = mouse0-1;
						}
						System.out.print("The location of the mouse is:" + mouse0 + "," + mouse1+ "\n");
			break;
			case 2: if (mapArray[mouse0+1][mouse1] == -1)
						{
						System.out.println("Your mouse has drowned, please try again.");
						drowns++;
						x=21;
						}
						else if (mapArray[mouse0+1][mouse1] == 99)
						{
						System.out.println("Your mouse has Escaped! hooray!");
						escapes++;
						x=21;
						}
						else
						{
						mapArray[mouse0+1][mouse1] = mapArray[mouse0][mouse1];
						mouse0 = mouse0+1;
						}
						System.out.print("The location of the mouse is:" + mouse0 + "," + mouse1+ "\n");
			break;
			case 3: if (mapArray[mouse0][mouse1-1] == -1)
						{
						System.out.println("Your mouse has drowned, please try again.");
						drowns++;
						x=21;
						}
						else if (mapArray[mouse0][mouse1-1] == 99)
						{
						System.out.println("Your mouse has Escaped! hooray!");
						escapes++;
						x=21;
						}
						else
						{
						mapArray[mouse0][mouse1-1] = mapArray[mouse0][mouse1];
						mouse1 = mouse1-1;
						}
						System.out.print("The location of the mouse is:" + mouse0 + "," + mouse1 + "\n");
			break;
			case 4: if (mapArray[mouse0][mouse1+1] == -1)
						{
						System.out.println("Your mouse has drowned, please try again.");
						drowns++;
						x=21;
						}
						else if (mapArray[mouse0][mouse1+1] == 99)
						{
						System.out.println("Your mouse has Escaped! hooray!");
						escapes++;
						x=21;
						}
						else
						{
						mapArray[mouse0][mouse1+1] = mapArray[mouse0][mouse1];
						mouse1 = mouse1+1;
						}
						System.out.print("The location of the mouse is:" + mouse0 + "," + mouse1+ "\n");
			break;
			}
			if (x == 20)
			{
			System.out.println("\nYou have exceeded the number of tries. Your mouse has starved to death -- good one.");
			}
					}
		System.out.println("\nThe bridges were located at " + m1coord0 + "," + m1coord1 + " and " + m2coord0 + "," + m2coord1);
	
	}
		System.out.print("Coded by Laura Cassell");
	}

}
	