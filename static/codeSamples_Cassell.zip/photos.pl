#!/usr/bin/perl

use warnings;
use strict;
use File::Copy;

my @array = </Volumes/NIKOND50/DCIM/100SEP06/DSC*>;
my $start = $ARGV[0];
my $stop;
my $name;

# start with file # to start, file # to end, dir name
# $~/perl photos.pl [start] [end] [dir]

if ($ARGV[2]) {
    $stop = $ARGV[1];
    $name = $ARGV[2];
}
else {
    $stop = 9999;
    $name = $ARGV[1];
}

my $dirname = join("", "/Users/lauramcfarland/Pictures/", $name );
unless (-e $dirname) {
mkdir($dirname, 0764) or die "make directory failed: $!";
}

for (@array) {

    $_ =~ m/(\d{4})/;
    my $photoname = join("", "$dirname/", $name, "_", $1, ".jpg");
   
    if ($1 >= $start && $1 <= $stop) {
        move ($_, $photoname) or die "Move failed: $!";
    }
}


