#import <stdio.h>

int main (int arg, char *argc[])

{
  int a = 0, b = 1, cur_fibo = 0, evenFibSum = 0;
  
  while (cur_fibo <= 4000000) {
    cur_fibo = a + b; 
    a = b;
    b = cur_fibo;
    if (cur_fibo % 2 == 0 )
      evenFibSum = evenFibSum + cur_fibo;
          }

  printf("The sum is %i\n", evenFibSum);
  return 0;
}
